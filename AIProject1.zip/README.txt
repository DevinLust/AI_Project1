Authors: Devin Lust and Jacob Bailey

Type "ptyhon UCSearch.py" or "python AstarSearch.py" in the command
line to run the programs. Include two input strings in the form
"ABCDP" to input the initial state. The first string inputs
which robot has not crossed and the second string inputs which
have crossed. For example, input 'python UCSearch.py "ABCDP" "" '
to run uniform cost search with all robots and power supply having
not crossed yet.